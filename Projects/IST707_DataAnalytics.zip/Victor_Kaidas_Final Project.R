# IST 707
# Victor Kaidas
# Project

# prepare data
happy <- read.csv('/Users/victo/Documents/Syr/DA/Proj/happiness_2015.csv', header=TRUE)
happy_disc <- read.csv('/Users/victo/Documents/Syr/DA/Proj/happiness_2015.csv', header=TRUE)

happy15 <- read.csv('/Users/victo/Documents/Syr/DA/Proj/happiness_2015.csv', header=TRUE)
happy16 <- read.csv('/Users/victo/Documents/Syr/DA/Proj/happiness_2016.csv', header=TRUE)
happy17 <- read.csv('/Users/victo/Documents/Syr/DA/Proj/happiness_2017.csv', header=TRUE)


# regional happiness
regions <- levels(happy$Region)
happyMeans15 <- c()
for(r in 1:length(regions)) {
  happyMeans15 <- c(happyMeans15, mean(happy15$Happiness.Score[which(happy15$Region==regions[r])]))
}
happyMeans16 <- c()
for(r in 1:length(regions)) {
  happyMeans16 <- c(happyMeans16, mean(happy16$Happiness.Score[which(happy16$Region==regions[r])]))
}

#store regions into 2017 data
for(h in 1:nrow(happy17)) {
  region <- happy16$Region[which(as.character(happy16$Country)==as.character(happy17$Country[h]))]
  if(length(region)>0) {
    happy17$Region[h] <- as.character(region[1])
  }
}

happyMeans17 <- c()
for(r in 1:length(regions)) {
  happyMeans17 <- c(happyMeans17, mean(happy17$Happiness.Score[which(happy17$Region==regions[r])]))
}

df <- data.frame(
  region = c(rep(c(regions), times=3)),
  year = c(rep(c(2015), times=10), rep(c(2016), times=10), rep(c(2017), times=10)), 
  score = c(happyMeans15, happyMeans16, happyMeans17)
)

mean(happy15$Economy..GDP.per.Capita.)
mean(happy15$Economy..GDP.per.Capita.[which(happy15$Region=='Sub-Saharan Africa')])
mean(happy15$Economy..GDP.per.Capita.[which(happy15$Region=='Southeastern Asia')])

mean(happy15$Health..Life.Expectancy.)
mean(happy15$Health..Life.Expectancy.[which(happy15$Region=='Sub-Saharan Africa')])
mean(happy15$Health..Life.Expectancy.[which(happy15$Region=='Southeastern Asia')])


library(RColorBrewer)
library(ggplot2)
myColors <- brewer.pal(9,"Set1")
myColors <- c(myColors, "#66C2A5")
names(myColors) <- regions
colScale <- scale_colour_manual(name = "region", values = myColors)

# Scatterplot
gg <- ggplot(df, aes(x=year, y=score, color=region)) + 
  geom_point() + 
  geom_smooth(method="loess", se=F) + 
  xlim(c(2015,2017)) + 
  scale_x_continuous(limits=c(2015, 2017), breaks=c(2015, 2016, 2017)) +
  #ylim(c(0,10)) + 
  labs(subtitle="Happiness by Region", 
       y="Happiness Score", 
       x="Year", 
       title="Scatterplot") +
  colScale

plot(gg)




# happiness to attempted coup correlation?

happy17$Happiness.Score[which(happy17$Country=='Guinea')]
ginScores <- c(3.656, 3.607, 3.507)

happy17$Happiness.Score[which(happy17$Country=='Zimbabwe')]
zimbScores <- c(4.61, 4.193, 3.857)

happy17$Happiness.Score[which(happy17$Country=='Montenegro')]
montScores <- c(5.192, 5.161, 5.237)

happy17$Happiness.Score[which(happy17$Country=='Burkina Faso')]
burkScores <- c(3.587, 3.739, 4.032)

happy15$Happiness.Score[which(happy15$Country=='Turkey')]
turkScores <- c(5.332, 5.389, 5.5) 

happy17$Happiness.Score[which(happy17$Country=='Libya')]
libScores <- c(5.754, 5.615, 5.525) 

df <- data.frame(
  rating=c(ginScores, zimbScores, montScores, burkScores, turkScores, libScores), 
  year=c(rep(c(2015,2016,2017), times=6)),
  country=c(c(rep(c('Guinea (2017)'), times=3)), c(rep(c('Zimbabwe (2017)'), times=3)), c(rep(c('Montenegro (2016)'), times=3)), c(rep(c('Burkina Faso (2016)'), times=3)), c(rep(c('Turkey (2016)'), times=3)), c(rep(c('Libya (2016)'), times=3)))
)

library(RColorBrewer)
myColors <- brewer.pal(6,"Set1")
names(myColors) <- levels(df$country)
colScale <- scale_colour_manual(name = "country",values = myColors)

# Scatterplot
gg <- ggplot(df, aes(x=year, y=rating, color=country)) + 
  geom_point() + 
  geom_smooth(method="loess", se=F) + 
  xlim(c(2015,2017)) + 
  scale_x_continuous(limits=c(2015, 2017), breaks=c(2015, 2016, 2017)) +
  #ylim(c(0,10)) + 
  labs(subtitle="Happiness by Year During Attempted Coup", 
       y="Happiness Score", 
       x="Year", 
       title="Scatterplot") +
  colScale

plot(gg)




changes <- c()
countries <- c()
for(i in nrow(happy17)) {
  country17 <- as.character(happy17$Country[i])
  country15 <- happy15[which(as.character(happy15$Country)==country17),]
  if(nrow(country15) > 0 ) {
    
    if(country15$Happiness.Score[1] < country17$Happiness.Score) {
      print(i)
    }
    
    #print(paste('15:', happy15$Happiness.Score, '17:' ,happy17$Happiness.Score))
    change <-  happy15$Happiness.Score[1] - happy17$Happiness.Score
    changes <- c(changes, change)
    countries <- c(countries, as.character(happy17$Country))
  }
}

df <- data.frame(
  country=countries, change=changes
)

df <- df[order(-df$change),][1:50,]


#barplot with range as color
#modify school names from ints to letters
ggplot(df, aes(x=country, y=change, fill=change)) + geom_bar(stat="identity") + ggtitle('Top 50 Happiness Changes between 2015-2017') + 
   theme(axis.text.x = element_text(angle = 90, hjust = 1))

# map it
library(RColorBrewer)
library(maptools)
library(ggplot2)
#install.packages('rworldmap')
library(rworldmap)

# map happiness
df <- data.frame(happy$Country, happy$Happiness.Score)
df$happy.Country <- as.character(df$happy.Country)

df$happy.Country[which(df$happy.Country=='Somaliland region')] <- 'Somalia'
df$happy.Country[which(df$happy.Country=='North Cyprus')] <- 'Cyprus'
df$happy.Country[which(df$happy.Country=='Palestinian Territories')] <- 'Palestine'
df$region <- df$happy.Country

map.world = map_data(map='world')
map.world$region[which(as.character(map.world$region)=='Democratic Republic of the Congo')] = 'Congo (Brazzaville)'
map.world$region[which(as.character(map.world$region)=='Republic of Congo')] = 'Congo (Kinshasa)'
map.world$region[which(as.character(map.world$region)=='Trinidad')] = 'Trinidad and Tobago'
map.world$region[which(as.character(map.world$region)=='Tobago')] = 'Trinidad and Tobago'
map.world$region[which(as.character(map.world$region)=='USA')] = 'United States'
map.world$region[which(as.character(map.world$region)=='UK')] = 'United Kingdom'

# which countries dont exist in map? 
#for(d in 1:nrow(df)) {
#  dfCountry <- as.character(df$happy.Country[d])
#  rows <- nrow(map.world[which(as.character(map.world$region)==dfCountry),])
#  if(rows==0) {
#    print(paste(dfCountry, 'rows: ', rows))
#  }
#}

map.world = merge(df,map.world, by='region',all.y=TRUE)
map.world = map.world[order(map.world$order), ] 

#map.world$region[which(map.world$region != happy$Country)]
#matrix(map.world)

ggplot() + 
  geom_map(data = map.world,map = map.world, aes(
    map_id = region,
    x=long,
    y=lat,
    fill=happy.Happiness.Score
  )) + 
  labs(title='World Happiness Scores (2015)') +
  coord_quickmap() +
  scale_fill_gradient2(name="Happiness Score", midpoint = 3, mid = "black", high = "orange")



# Normalize data
# convert numbers to nearest int, factorize
for(i in 6:11) {
  happy[,i] <- floor((happy[,i] / max(happy[,i]) ) * 10)
  happy[,i] <- as.factor(happy[,i])
}

# factorize happiness column
happy$Happiness.Score <- floor(happy$Happiness.Score)
happy$Happiness.Score <- as.factor(happy$Happiness.Score)

# Discretization happy_score, factor columns
for(i in c(4)) {
  happy_disc[,i] <- floor((happy_disc[,i] / max(happy_disc[,i]) ) * 100)
  happy_disc[,i] <- cut(happy_disc[,i], breaks = c(0,20,40,60,80,100),labels=c("low","low-medium","medium","medium-high","high"))
}



########## PREDICT HAPPINESS FROM 6 FACTORS? #############

# split data into 70/30: training/test
happyFactors <- happy[ ,c(4, 6:11)] # just get the factors
happyFactors_disc <- happy_disc[ ,c(4, 6:11)] # just get the factors


# Gain ratio
#install.packages('FSelector')
library(FSelector)

factor_weights <- gain.ratio(Happiness.Score~., happyFactors_disc)
factor_weights_df <- as.data.frame(factor_weights)
factor_weights_df$word <- colnames(factor_weights_df)
factor_weights_df[order(-factor_weights_df$attr_importance),]

set.seed(100)
rand <- sample(1:nrow(happyFactors), round(nrow(happyFactors)*.70), replace=F)
train <- happyFactors[rand,]
test <- happyFactors[-rand,] 
train_disc <- happyFactors_disc[rand,]
test_disc <- happyFactors_disc[-rand,] 

# J48 ->  M=16, 74.47%, discretized
library(RWeka)
# best value for M
mvals <- c()
accurs <- c()
for(m in 1:50) {
  avg <- 0
  for(j in 1:5) {
    j48  <- J48(Happiness.Score~., data=train_disc, control=Weka_control(U=F, M=m, C=0.5)) 
    pred <- predict(j48, newdata=test_disc[,-1], type=c("class"))
    acc <- length(which(as.numeric(pred)==as.numeric(test_disc[,1]))) / nrow(test_disc)
    avg <- avg + acc
    if(j==5) {
      avg <- avg / 5
      mvals <<- c(mvals, m)
      accurs <<- c(accurs, avg)
    }
  }
}
k_acc <- data.frame(m=mvals, accurs=accurs)
library(ggplot2)
ggplot() + geom_line(aes(y = accurs, x = m), data = k_acc, stat="identity") + 
  scale_x_continuous(breaks=seq(1,50,1)) + xlab('k') + ylab('Accuracy %')
print(paste('J48:', max(accurs), ', M:', mvals[which(accurs==max(accurs))][1]))

# NB -> 72.23%, laplace=0, discretized
library(e1071)
# best value for laplace
laps <- c()
accurs <- c()
for(a in 0:50) {
  nb <- naiveBayes(Happiness.Score~., data=train_disc, laplace = a, na.action = na.pass)
  pred <- predict(nb, newdata=test_disc[,-1], type=c("class"))
  len <- length(which(pred==test_disc$Happiness.Score)) / nrow(test_disc)
  laps <<- c(laps, a)
  accurs <<- c(accurs, len)
}
lap_acc <- data.frame(laplace=laps, accurs=accurs)
library(ggplot2)
ggplot() + geom_line(aes(y = accurs, x = laplace), data = lap_acc, stat="identity") + 
  scale_x_continuous(breaks=seq(0,50,1)) + xlab('laplace') + ylab('Accuracy %')
print(paste('NB:', max(accurs), ', Laplace:', laps[which(accurs==max(accurs))][1]))

# kNN -> k=19, accuracy: 75.53%
library(class)
# best value for k
k <- c()
accurs <- c()
for(i in 1:20) {
  avg <- 0
  for(j in 1:10) {
    pred <- knn(train=train_disc[-1], test=test_disc[,-1], cl=train_disc[,1], k=i)
    acc <- length(which(as.numeric(pred)==as.numeric(test_disc[,1]))) / nrow(test_disc)
    avg <- avg + acc
    if(j==10) {
      avg <- avg / 10
      k <<- c(k, i)
      accurs <<- c(accurs, avg)
    }
  }
}
k_acc <- data.frame(k=k, accurs=accurs)
library(ggplot2)
ggplot() + geom_line(aes(y = accurs, x = k), data = k_acc, stat="identity") + 
  scale_x_continuous(breaks=seq(1,20,1)) + xlab('k') + ylab('Accuracy %')
print(paste('kNN:', max(accurs), ', k:', k[which(accurs==max(accurs))][1]))

# SVM > kernal=polynomial, cost=4, accuracy=76.60%, discretized all in 5 bins
costs <- c()
accurs <- c()
for(i in 1:20) {
  svm <- svm <- svm(Happiness.Score~., data=train_disc, kernal='polynomial', cost=i,  scale=FALSE) #kernals=linear,polynomial,radial,sigmoid
  pred <- predict(svm, newdata=test_disc[-1], type=c("class"))
  acc <- length(which(pred==test_disc$Happiness.Score)) / nrow(test_disc)
  costs <<- c(costs, i)
  accurs <<- c(accurs, acc)
}
cost_acc <- data.frame(costs=costs, accurs=accurs)
ggplot() + geom_line(aes(y = accurs, x = costs), data = cost_acc, stat="identity") + 
  scale_x_continuous(breaks=seq(0,20,1)) + xlab('Cost') + ylab('Accuracy %')
print(paste('SVM:', max(accurs), ', cost:', costs[which(accurs==max(accurs))][1]))

# random forest -> ntree=55, 59.57%, not-discretized
#install.packages("randomForest")
library(randomForest)
ntrees <- c()
accurs <- c()
for(i in seq(0,100, 5)) {
  rfm <- randomForest(Happiness.Score~., data=train, ntree=(i+1))
  pred <- predict(rfm, test[,-1], type=c("class"))
  acc <- length(which(as.numeric(pred)==as.numeric(test[,1]))) / nrow(test) 
  ntrees <<- c(ntrees, i)
  accurs <<- c(accurs, acc)
}
ntree_acc <- data.frame(ntrees=ntrees, accurs=accurs)
ggplot() + geom_line(aes(y = accurs, x = ntrees), data = ntree_acc, stat="identity") + 
  scale_x_continuous(breaks=seq(0,100,5)) + xlab('ntrees') + ylab('Accuracy %')
print(paste('Random forest:', max(accurs), ', ntree:', ntrees[which(accurs==max(accurs))][1]))

# HAC clustering
# single -> 1.9%
s <- hclust(dist(happyFactors[-1]), method = 'single')
scut <- cutree(s, 6)
len <- length(which(as.numeric(scut)==as.numeric(happyFactors$Happiness.Score))) / nrow(happyFactors)
print(paste('HAC (single):', len))

# complete -> 5.7%, un-discretized
c <- hclust(dist(happyFactors[-1]), method = 'complete')
#c1 <- hclust(dist(happyFactors[-1], method = 'cosine'), method = 'complete')
ccut <- cutree(c, 6)
len <- length(which(as.numeric(ccut)==as.numeric(happyFactors$Happiness.Score))) / nrow(happyFactors)
print(paste('HAC (complete):', len))

# avg -> 17.72%, undiscretized
a <- hclust(dist(happyFactors[-1]), method = 'average')
acut <- cutree(a, 6)
len <- length(which(as.numeric(acut)==as.numeric(happyFactors$Happiness.Score))) / nrow(happyFactors)
print(paste('HAC (average):', len))


##### More from SVM model #####
library(e1071)
wrongCountries <- c()
wrongRegions <- c()
happyFactors_disc <- happy_disc[ ,c(1,2,4, 6:11)] # scountry, region, happiness_score, 6 factors

for(i in 0:1000) {
  set.seed(i)
  rand <- sample(1:nrow(happyFactors_disc), round(nrow(happyFactors_disc)*.70), replace=F)
  train_disc <- happyFactors_disc[rand,]
  test_disc <- happyFactors_disc[-rand,] 
  
  svm <- svm(Happiness.Score~., data=train_disc[-c(1,2)], kernal='polynomial', cost=4,  scale=FALSE) #kernals=linear,polynomial,radial,sigmoid
  pred <- predict(svm, newdata=test_disc[-c(1:3)], type=c("class"))
  
  countries <- test_disc$Country[which(pred!=test_disc$Happiness.Score)]
  wrongCountries <<- c(wrongCountries, as.character(countries))
  
  regions <- test_disc$Region[which(pred!=test_disc$Happiness.Score)]
  wrongRegions <<- c(wrongRegions, as.character(regions))
}

# which regions are represented?
table(wrongRegions)



df <- as.data.frame(table(wrongCountries))
df$wrongCountries <- as.character(df$wrongCountries)
df$wrongCountries[which(df$wrongCountries=='Somaliland region')] <- 'Somalia'
df$wrongCountries[which(df$wrongCountries=='North Cyprus')] <- 'Cyprus'
df$region <- df$wrongCountries
df$Freq <- (df$Freq/300) * 100

bad <- df[order(-df$Freq),][1:20,] #top 20

# get mean happy score of incorrectly predicted countries -> 4.27
scores <- c()
for(i in nrow(bad)) {
  score <- happy$Happiness.Score[which(happy$Country==bad$wrongCountries[i])]
  scores <- c(scores, score)
}
mean(scores) 


# which countries dont exist in map? 
#for(d in 1:nrow(df)) {
#  dfCountry <- as.character(df$wrongCountries[d])
#  rows <- nrow(map.world[which(as.character(map.world$region)==dfCountry),])
#  if(rows==0) {
#    print(paste(dfCountry, 'rows: ', rows))
#  }
#}

library(RColorBrewer)
library(maptools)
library(ggplot2)
#install.packages('rworldmap')
library(rworldmap)


map.world = merge(df,map.world, by='region',all.y=TRUE)
map.world = map.world[order(map.world$order), ] 

ggplot() + 
  geom_map(data = map.world,map = map.world, aes(
    map_id = region,
    x=long,
    y=lat,
    fill=Freq
  )) + 
  labs(title='Countries Predicted Incorrectly with SVM Model') +
  coord_quickmap() +
  scale_fill_gradient2(name="Frequency (%)", midpoint = 0, mid = "#7F7F7F", high = "red")





############# INTERNET USAGE CORRELATION? #################
iusr <- read.csv('/Users/victo/Documents/Syr/DA/Proj/InternetUsage.csv', header=TRUE)
happy <- read.csv('/Users/victo/Documents/Syr/DA/Proj/happiness_2017.csv', header=TRUE)
iusr <- iusr[-which(is.na(iusr$X2017)) ,] # remove na's

country <- c()
iFreq <- c()
hScore <- c()
for(i in 1:nrow(iusr)) {
  happyRow <- happy[which(as.character(happy$Country)==as.character(iusr$�..Country.Name[i])),]
  if((nchar(as.character(iusr$X2017[i])) > 0) & (nrow(happyRow) > 0)) {
    country <- c(country, as.character(happyRow$Country))
    hScore <- c(hScore, happyRow$Happiness.Score)
    iFreq <- c(iFreq, iusr$X2017[i])
  }
}
iusr2happy <- data.frame(country, iFreq, hScore)


# plot
options(scipen=999)  # turn-off scientific notation like 1e+48
theme_set(theme_bw())  # pre-set the bw theme.
# midwest <- read.csv("http://goo.gl/G1K41K")  # bkup data source


ggplot(iusr2happy, aes(x=hScore, y=iFreq)) +
  geom_point(shape=1)  

# Scatterplot
gg <- ggplot(iusr2happy, aes(x=hScore, y=iFreq)) + 
  geom_point(shape=1) + 
  geom_smooth(method="loess", se=F) + 
  xlim(c(2.5,7.5)) + 
  ylim(c(0,100)) + 
  labs(subtitle="Internet Usage by Happiness", 
       y="Internet Usage Frequency", 
       x="Happiness Score", 
       title="Scatterplot")

plot(gg)

linModel <- lm(hScore ~ iFreq, data=iusr2happy)
summary(linModel)
cor(iusr2happy$hScore, iusr2happy$iFreq) 


############# ALCOHOL CONSUMTION CORRELATION? #################

terrain <- read.csv('/Users/victo/Documents/Syr/DA/Proj/rugged_data.csv', header=TRUE)
# make distCoast a percent
terrain$dist_coast <- (terrain$dist_coast / max(terrain$dist_coast) ) * 100

country <- c()
tropFreq <- c()
desertFreq <- c()
coastFreq <- c()
hScore <- c()
for(i in 1:nrow(terrain)) {
  happyRow <- happy[which(as.character(happy$Country)==as.character(terrain$country[i])),]
  if(nrow(happyRow) > 0) {
    country <- c(country, as.character(happyRow$Country))
    hScore <- c(hScore, happyRow$Happiness.Score)
    tropFreq <- c(tropFreq, terrain$tropical[i])
    desertFreq <- c(desertFreq, terrain$desert[i])
    coastFreq <- c(coastFreq, terrain$dist_coast[i])
  }
}

tropic2happy <- data.frame(country, hScore, freq=tropFreq, Terrain='Tropical')
desert2happy <- data.frame(country, hScore, freq=desertFreq, Terrain='Desert')
coast2happy <- data.frame(country, hScore, freq=coastFreq, Terrain='Distance to Coast')
terrain2happy <- rbind(tropic2happy, desert2happy)
terrain2happy <- rbind(terrain2happy, coast2happy)

library(RColorBrewer)
library(ggplot2)
myColors <- brewer.pal(3,"Set1")
names(myColors) <- levels(terrain2happy$Terrain)
colScale <- scale_colour_manual(name = "cat1",values = myColors)

#terrain2happy <- data.frame(country, tropFreq, desertFreq, coastFreq, hScore)



# Scatterplot
gg <- ggplot(terrain2happy, aes(x=hScore, y=freq, color=Terrain)) + 
  geom_point() + 
  geom_smooth(method="loess", se=F) + 
  xlim(c(2.5,7.5)) + 
  ylim(c(0,100)) + 
  labs(subtitle="Happiness by Terrain", 
       y="% Frequncy of Climate", 
       x="Happiness Score", 
       title="Scatterplot") +
  colScale

plot(gg)

linModel <- lm(hScore ~ freq, data=coast2happy)
summary(linModel)
cor(coast2happy$hScore, coast2happy$freq) 


##########################################################################



library(plyr)
library(dplyr)
library(tidyverse)
library(lubridate)
library(caTools)
library(ggplot2)
library(ggthemes)
library(reshape2)
library(data.table)
library(tidyr)
library(corrgram)       
library(corrplot)
library(formattable)
library(cowplot)
library(ggpubr)
library(plot3D)

Happiness17 <- read.csv("C:/Users/laure/Documents/Masters- Applied Data Science/IST 707/Final Project/Data Sets/2017.csv")
str(Happiness17)

#Cleaning
colnames (Happiness17) <- c("Country", "Happiness.Rank", "Happiness.Score",
                            "Whisker.High", "Whisker.Low", "Economy", "Family",
                            "Life.Expectancy", "Freedom", "Generosity",
                            "Trust", "Dystopia.Residual")

Happiness17 <- Happiness17[, -c(4,5)]

# Creating a new column for continents

Happiness17$Continent <- NA

Happiness17$Continent[which(Happiness17$Country %in% c("Israel", "United Arab Emirates", "Singapore", "Thailand", "Taiwan Province of China",
                                                       "Qatar", "Saudi Arabia", "Kuwait", "Bahrain", "Malaysia", "Uzbekistan", "Japan",
                                                       "South Korea", "Turkmenistan", "Kazakhstan", "Turkey", "Hong Kong S.A.R., China", "Philippines",
                                                       "Jordan", "China", "Pakistan", "Indonesia", "Azerbaijan", "Lebanon", "Vietnam",
                                                       "Tajikistan", "Bhutan", "Kyrgyzstan", "Nepal", "Mongolia", "Palestinian Territories",
                                                       "Iran", "Bangladesh", "Myanmar", "Iraq", "Sri Lanka", "Armenia", "India", "Georgia",
                                                       "Cambodia", "Afghanistan", "Yemen", "Syria"))] <- "Asia"
Happiness17$Continent[which(Happiness17$Country %in% c("Norway", "Denmark", "Iceland", "Switzerland", "Finland",
                                                       "Netherlands", "Sweden", "Austria", "Ireland", "Germany",
                                                       "Belgium", "Luxembourg", "United Kingdom", "Czech Republic",
                                                       "Malta", "France", "Spain", "Slovakia", "Poland", "Italy",
                                                       "Russia", "Lithuania", "Latvia", "Moldova", "Romania",
                                                       "Slovenia", "North Cyprus", "Cyprus", "Estonia", "Belarus",
                                                       "Serbia", "Hungary", "Croatia", "Kosovo", "Montenegro",
                                                       "Greece", "Portugal", "Bosnia and Herzegovina", "Macedonia",
                                                       "Bulgaria", "Albania", "Ukraine"))] <- "Europe"
Happiness17$Continent[which(Happiness17$Country %in% c("Canada", "Costa Rica", "United States", "Mexico",  
                                                       "Panama","Trinidad and Tobago", "El Salvador", "Belize", "Guatemala",
                                                       "Jamaica", "Nicaragua", "Dominican Republic", "Honduras",
                                                       "Haiti"))] <- "North America"
Happiness17$Continent[which(Happiness17$Country %in% c("Chile", "Brazil", "Argentina", "Uruguay",
                                                       "Colombia", "Ecuador", "Bolivia", "Peru",
                                                       "Paraguay", "Venezuela"))] <- "South America"
Happiness17$Continent[which(Happiness17$Country %in% c("New Zealand", "Australia"))] <- "Australia"
Happiness17$Continent[which(is.na(Happiness17$Continent))] <- "Africa"


# Moving the continent column's position in the dataset to the second column

Happiness17 <- Happiness17 %>% select(Country,Continent, everything())

# Changing Continent column to factor

Happiness17$Continent <- as.factor(Happiness17$Continent)

str(Happiness17)

## Correlation between variables

# Finding the correlation between numerical columns
Num.cols <- sapply(Happiness17, is.numeric)
Cor.data <- cor(Happiness17[, Num.cols])

corrplot(Cor.data, method = 'shade')  

# Create a correlation plot
newdatacor = cor(Happiness17[c(4:11)])
corrplot(newdatacor, method = "number")


corrgram(Happiness17 %>% select(-3) %>% filter(Continent == "North America"), order=TRUE,
         upper.panel=panel.cor, main="Happiness Matrix for North America")


####### Happiness score for each continent

gg1 <- ggplot(Happiness17,
              aes(x=Continent,
                  y=Happiness.Score,
                  color=Continent))+
  geom_point() + theme_bw() +
  theme(axis.title = element_text(family = "Helvetica", size = (8)))

gg2 <- ggplot(Happiness17 , aes(x = Continent, y = Happiness.Score)) +
  geom_boxplot(aes(fill=Continent)) + theme_bw() +
  theme(axis.title = element_text(family = "Helvetica", size = (8)))

gg3 <- ggplot(Happiness17,aes(x=Continent,y=Happiness.Score))+
  geom_violin(aes(fill=Continent),alpha=0.7)+ theme_bw() +
  theme(axis.title = element_text(family = "Helvetica", size = (8)))

# Compute descriptive statistics by groups
stable <- desc_statby(Happiness17, measure.var = "Happiness.Score",
                      grps = "Continent")
stable <- stable[, c("Continent","mean","median")]
names(stable) <- c("Continent", "Mean of happiness score","Median of happiness score")
# Summary table plot
stable.p <- ggtexttable(stable,rows = NULL, 
                        theme = ttheme("classic"))

ggarrange(gg3, stable.p, ncol = 1, nrow = 2)



#::::::::::::::::::::::::::::Health::::::::::::::::::::::::::::::
View(Happiness17)
sp <- ggscatter(Happiness17, x = "Life.Expectancy", y = "Happiness.Score",
                color = "Continent", palette = "jco",
                size = 3, alpha = 0.6)
# Create box plots of x/y variables
# Box plot of the x variable
xbp <- ggboxplot(Happiness17$Life.Expectancy, width = 0.3, fill = "green") +
  rotate() +
  theme_transparent()
# Box plot of the y variable
ybp <- ggboxplot(Happiness17$Happiness.Score, width = 0.3, fill = "purple") +
  theme_transparent()
# Create the external graphical objects
# called a "grop" in Grid terminology
xbp_grob <- ggplotGrob(xbp)
ybp_grob <- ggplotGrob(ybp)
# Place box plots inside the scatter plot
xmin <- min(Happiness17$Life.Expectancy); xmax <- max(Happiness17$Life.Expectancy)
ymin <- min(Happiness17$Happiness.Score); ymax <- max(Happiness17$Happiness.Score)
yoffset <- (1/15)*ymax; xoffset <- (1/15)*xmax
# Insert xbp_grob inside the scatter plot
sp + annotation_custom(grob = xbp_grob, xmin = xmin, xmax = xmax, 
                       ymin = ymin-yoffset, ymax = ymin+yoffset) +
  # Insert ybp_grob inside the scatter plot
  annotation_custom(grob = ybp_grob,
                    xmin = xmin-xoffset, xmax = xmin+xoffset, 
                    ymin = ymin, ymax = ymax)






#Decision Trees
dt = rpart(formula = Happiness.Score ~ .,
           data = Happiness17,
           control = rpart.control(minsplit = 10))
library(rpart.plot)
prp(regressor_dt)


dt1 = rpart(formula = Happiness.Score ~ Economy+ Family+Life.Expectancy,
            data = Happiness17,
            control = rpart.control(minsplit = 10))

prp(dt1)

dt2 = rpart(formula = Happiness.Score ~ Continent+Economy,
            data = Happiness17,
            control = rpart.control(minsplit = 10))

prp(dt2)

#SVM
library(e1071)
happiness_SVM = svm(formula = Happiness.Score ~ .,
                    data = Happiness17,
                    type = 'eps-regression',
                    kernel = 'radial')
print(happiness_SVM)
plot(happiness_SVM, Happiness17~., data=happiness_SVM)


happiness_SVM1 = svm(formula = Happiness.Score ~ Economy + Family + Life.Expectancy,
                     data = Happiness17,
                     type = 'eps-regression',
                     kernel = 'linear')
print(happiness_SVM1)
plot(happiness_SVM1, Happiness17~., data=happiness_SVM)





