-- START INSTALL --


-- Functions --

-- Create function to get Division ID by Name
-- Drop if exists
IF OBJECT_ID('dbo.fnGetDivisionID') IS NOT NULL
DROP FUNCTION dbo.fnGetDivisionID;
GO
-- Create it
CREATE FUNCTION dbo.fnGetDivisionID (@Name varchar(50))
RETURNS int 
AS
BEGIN
	DECLARE @DivisionID int
		SET @DivisionID = (SELECT Top 1 DivisionID FROM Division WHERE Name = @Name)
	RETURN @DivisionID
END
GO

-- Create function to get Team ID by Name
-- Drop if exists
IF OBJECT_ID('dbo.fnGetTeamID') IS NOT NULL
DROP FUNCTION dbo.fnGetTeamID;
GO
-- Create it
CREATE FUNCTION dbo.fnGetTeamID (@Name varchar(50))
RETURNS int 
AS
BEGIN
	DECLARE @TeamID int
		SET @TeamID = (SELECT Top 1 TeamID FROM Team WHERE Name = @Name)
	RETURN @TeamID
END
GO

-- Create function to get Status ID by Name
-- Drop if exists
IF OBJECT_ID('dbo.fnGetStatusID') IS NOT NULL
DROP FUNCTION dbo.fnGetStatusID;
GO
-- Create it
CREATE FUNCTION dbo.fnGetStatusID (@Name varchar(50))
RETURNS int 
AS
BEGIN
	DECLARE @StatusID int
		SET @StatusID = (SELECT Top 1 StatusID FROM Status WHERE Name = @Name)
	RETURN @StatusID
END
GO

-- Function to get team's next game and see if the spread was beat, used by reports
-- Drop if exists
IF OBJECT_ID('dbo.fnDidTeamCoverNextGame') IS NOT NULL
DROP FUNCTION dbo.fnDidTeamCoverNextGame;
GO
CREATE FUNCTION dbo.fnDidTeamCoverNextGame(@TeamID int, @GameDate DateTime, @SpreadToBeat decimal(3,1))
RETURNS bit
AS
BEGIN
	DECLARE @Result bit = 0
	
	IF((SELECT COUNT(NextGame.GameID) 

		FROM (SELECT TOP 1 *
			FROM Game
			JOIN Line AS AwayTeamLine ON Game.AwayTeamLineID = AwayTeamLine.LineID
			WHERE (AwayTeamID = @TeamID OR HomeTeamID = @TeamID) AND StartDate > @GameDate
			ORDER BY StartDate
		) AS NextGame
		WHERE (@TeamID = NextGame.AwayTeamID AND (NextGame.HomeTeamScore - NextGame.AwayTeamScore) < @SpreadToBeat) OR 
			(@TeamID = NextGame.HomeTeamID AND (NextGame.AwayTeamScore - NextGame.HomeTeamScore) < @SpreadToBeat)
	
	) = 1) 
	SET @Result = 1;

	RETURN @Result
END
GO


-- Function to get team's next game and see if the spread was beat, used by reports
-- Drop if exists
IF OBJECT_ID('dbo.fnDidTeamLoseLast2AwayGames') IS NOT NULL
DROP FUNCTION dbo.fnDidTeamLoseLast2AwayGames;
GO
CREATE FUNCTION dbo.fnDidTeamLoseLast2AwayGames(@TeamID int, @GameDate DateTime)
RETURNS bit
AS
BEGIN
	DECLARE @Result bit = 0
	
	IF((SELECT COUNT(PrevGames.GameID) 

		FROM (SELECT TOP 2 *
			FROM Game
			WHERE (AwayTeamID = @TeamID OR HomeTeamID = @TeamID) AND StartDate < @GameDate
			ORDER BY StartDate DESC
		) AS PrevGames
		WHERE @TeamID = PrevGames.AwayTeamID AND (PrevGames.AwayTeamScore < PrevGames.HomeTeamScore) 
	
	) = 2) 
	SET @Result = 1;

	RETURN @Result
END
GO


-- End Functions


-- Create and populate tables --

-- Division Table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name = 'Division' AND xtype = 'U')
BEGIN
	-- Create Division table
	CREATE TABLE Division (
		DivisionID int IDENTITY(1,1) NOT NULL,
		Name varchar(50) NOT NULL, 
		PRIMARY KEY (DivisionID), 
		CONSTRAINT uq_Division_Name UNIQUE(Name)
	)
	-- Populate Division table
	INSERT INTO Division(Name) VALUES ('AFC East'), ('AFC West'), ('AFC North'), ('AFC South'), ('NFC East'), ('NFC West'), ('NFC North'), ('NFC South')
END

-- Team Table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name = 'Team' AND xtype = 'U')
BEGIN
	-- Creates the Team table
	CREATE TABLE Team (
		TeamID int IDENTITY(1,1) NOT NULL,
		Name varchar(50) NOT NULL,
		Location varchar(50) NOT NULL,
		DivisionID int NOT NULL, 
		PRIMARY KEY (TeamID), 
		FOREIGN KEY (DivisionID) REFERENCES Division(DivisionID)
	)
	-- Populates the Team table
	INSERT INTO Team(Name, Location, DivisionID) 
	VALUES 
		('Patriots', 'New England', dbo.fnGetDivisionID('AFC East')), 
		('Dolphins', 'Miami', dbo.fnGetDivisionID('AFC East')), 
		('Bills', 'Buffalo', dbo.fnGetDivisionID('AFC East')), 
		('Jets', 'New York', dbo.fnGetDivisionID('AFC East')), 
		('Chiefs', 'Kansas City', dbo.fnGetDivisionID('AFC West')), 
		('Chargers', 'San Diego', dbo.fnGetDivisionID('AFC West')), 
		('Broncos', 'Denver', dbo.fnGetDivisionID('AFC West')), 
		('Raiders', 'Oakland', dbo.fnGetDivisionID('AFC West')), 
		('Steelers', 'Pittsburgh', dbo.fnGetDivisionID('AFC North')), 
		('Ravens', 'Baltimore', dbo.fnGetDivisionID('AFC North')), 
		('Bengals', 'Cincinatti', dbo.fnGetDivisionID('AFC North')), 
		('Browns', 'Cleveland', dbo.fnGetDivisionID('AFC North')), 
		('Texans', 'Houston', dbo.fnGetDivisionID('AFC South')), 
		('Titans', 'Tennessee', dbo.fnGetDivisionID('AFC South')), 
		('Colts', 'Indianapolis', dbo.fnGetDivisionID('AFC South')), 
		('Jaguars', 'Jacksonville', dbo.fnGetDivisionID('AFC South')), 
		('Cowboys', 'Dallas', dbo.fnGetDivisionID('NFC East')), 
		('Eagles', 'Philadelphia', dbo.fnGetDivisionID('NFC East')), 
		('Redskins', 'Washington', dbo.fnGetDivisionID('NFC East')), 
		('Giants', 'New York', dbo.fnGetDivisionID('NFC East')), 
		('Rams', 'Los Angeles', dbo.fnGetDivisionID('NFC West')), 
		('Seahawks', 'Seattle', dbo.fnGetDivisionID('NFC West')), 
		('Cardinals', 'St. Louis', dbo.fnGetDivisionID('NFC West')), 
		('49ers', 'San Francisco', dbo.fnGetDivisionID('NFC West')), 
		('Bears', 'Chicago', dbo.fnGetDivisionID('NFC North')), 
		('Vikings', 'Minnesota', dbo.fnGetDivisionID('NFC North')), 
		('Packers', 'Green Bay', dbo.fnGetDivisionID('NFC North')), 
		('Lions', 'Detroit', dbo.fnGetDivisionID('NFC North')), 
		('Saints', 'New Orleans', dbo.fnGetDivisionID('NFC South')), 
		('Panthers', 'Carolina', dbo.fnGetDivisionID('NFC South')), 
		('Buccaneers', 'Tampa Bay', dbo.fnGetDivisionID('NFC South')), 
		('Falcons', 'Atlanta', dbo.fnGetDivisionID('NFC South'))
END

-- Line table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name = 'Line' AND xtype = 'U')
BEGIN
	-- Create table
	CREATE TABLE Line (
		LineID int IDENTITY(1,1) NOT NULL,
		PointSpread decimal(3,1) NOT NULL,
		SpreadOdds int NOT NULL, 
		MoneyLineOdds int NOT NULL, 
		PRIMARY KEY (LineID)
	)
	-- Insert rows
	INSERT INTO Line(PointSpread, SpreadOdds, MoneyLineOdds) VALUES (10, 108, 385)
	INSERT INTO Line(PointSpread, SpreadOdds, MoneyLineOdds) VALUES (-10, -102, -450)
	INSERT INTO Line(PointSpread, SpreadOdds, MoneyLineOdds) VALUES (-3, 106, -142)
	INSERT INTO Line(PointSpread, SpreadOdds, MoneyLineOdds) VALUES (3, -117, 129)
	INSERT INTO Line(PointSpread, SpreadOdds, MoneyLineOdds) VALUES (1, 101, 106)
	INSERT INTO Line(PointSpread, SpreadOdds, MoneyLineOdds) VALUES (-1, -112, -117)
	INSERT INTO Line(PointSpread, SpreadOdds, MoneyLineOdds) VALUES (3, -127, 126)
	INSERT INTO Line(PointSpread, SpreadOdds, MoneyLineOdds) VALUES (-3, 113, -140)
	INSERT INTO Line(PointSpread, SpreadOdds, MoneyLineOdds) VALUES (3, -103, 144)
	INSERT INTO Line(PointSpread, SpreadOdds, MoneyLineOdds) VALUES (-3, -107, -159)
	INSERT INTO Line(PointSpread, SpreadOdds, MoneyLineOdds) VALUES (3.5, -105, 163)
	INSERT INTO Line(PointSpread, SpreadOdds, MoneyLineOdds) VALUES (-2.5, -105, -181)
	INSERT INTO Line(PointSpread, SpreadOdds, MoneyLineOdds) VALUES (2.5, -103, 173)
	INSERT INTO Line(PointSpread, SpreadOdds, MoneyLineOdds) VALUES (-3.5, -108, -192)
	INSERT INTO Line(PointSpread, SpreadOdds, MoneyLineOdds) VALUES (6, 100, 253)
	INSERT INTO Line(PointSpread, SpreadOdds, MoneyLineOdds) VALUES (-6, -111, -286)
	INSERT INTO Line(PointSpread, SpreadOdds, MoneyLineOdds) VALUES (3, -110, 139)
	INSERT INTO Line(PointSpread, SpreadOdds, MoneyLineOdds) VALUES (-3, -101, -154)	
	INSERT INTO Line(PointSpread, SpreadOdds, MoneyLineOdds) VALUES (3, 102, 146)	
	INSERT INTO Line(PointSpread, SpreadOdds, MoneyLineOdds) VALUES (-3, -114, -162)	
	INSERT INTO Line(PointSpread, SpreadOdds, MoneyLineOdds) VALUES (2.5, -101, 115)	
	INSERT INTO Line(PointSpread, SpreadOdds, MoneyLineOdds) VALUES (-2.5, -110, -127)	
	INSERT INTO Line(PointSpread, SpreadOdds, MoneyLineOdds) VALUES (-3.5, -101, -185)	
	INSERT INTO Line(PointSpread, SpreadOdds, MoneyLineOdds) VALUES (3.5, -110, 166)	
	INSERT INTO Line(PointSpread, SpreadOdds, MoneyLineOdds) VALUES (-10, 102, -407)	
	INSERT INTO Line(PointSpread, SpreadOdds, MoneyLineOdds) VALUES (10, -114, 351)	
END

-- Create the Status table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name = 'Status' AND xtype = 'U')
BEGIN
	CREATE TABLE Status (
		StatusID int IDENTITY(1,1) NOT NULL,
		Name varchar(50) NOT NULL, 
		PRIMARY KEY (StatusID), 
		CONSTRAINT uq_Status_Name UNIQUE(Name)
	)
	INSERT INTO Status(Name) VALUES ('Scheduled'), ('Cancelled'), ('Ongoing'), ('Complete')
END

-- Game table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name = 'Game' AND xtype = 'U')
BEGIN
	-- Create the table
	CREATE TABLE Game (
		GameID int IDENTITY(1,1) NOT NULL,
		StartDate DateTime NOT NULL,
		AwayTeamID int NOT NULL, 
		HomeTeamID int NOT NULL, 
		AwayTeamLineID int, 
		HomeTeamLineID int, 
		AwayTeamScore int, 
		HomeTeamScore int, 
		StatusID int NOT NULL, 
		PRIMARY KEY (GameID), 
		FOREIGN KEY (AwayTeamID) REFERENCES Team(TeamID), 
		FOREIGN KEY (HomeTeamID) REFERENCES Team(TeamID), 
		FOREIGN KEY (AwayTeamLineID) REFERENCES Line(LineID), 
		FOREIGN KEY (HomeTeamLineID) REFERENCES Line(LineID), 
		FOREIGN KEY (StatusID) REFERENCES Status(StatusID)
	)
	-- Populates the table
	INSERT INTO Game(StartDate, AwayTeamID, HomeTeamID, AwayTeamLineID, HomeTeamLineID, AwayTeamScore, HomeTeamScore, StatusID) 
	VALUES 
		('2018-09-09 13:00:00', dbo.fnGetTeamID('Buccaneers'), dbo.fnGetTeamID('Saints'), 1, 2, 48, 40, dbo.fnGetStatusID('Complete')), 
		('2018-09-16 13:00:00', dbo.fnGetTeamID('Eagles'), dbo.fnGetTeamID('Buccaneers'), 3, 4, 21, 27, dbo.fnGetStatusID('Complete')), 
		('2018-09-24 20:15:00', dbo.fnGetTeamID('Steelers'), dbo.fnGetTeamID('Buccaneers'), 5, 6, 30, 27, dbo.fnGetStatusID('Complete')), 
		('2018-09-30 13:00:00', dbo.fnGetTeamID('Buccaneers'), dbo.fnGetTeamID('Bears'), 7, 8, 10, 48, dbo.fnGetStatusID('Complete')), 
		('2018-10-14 13:00:00', dbo.fnGetTeamID('Buccaneers'), dbo.fnGetTeamID('Falcons'), 9, 10, 3, 34, dbo.fnGetStatusID('Complete')), 
		('2018-10-21 20:15:00', dbo.fnGetTeamID('Buccaneers'), dbo.fnGetTeamID('Bears'), 11, 12, 3, 26, dbo.fnGetStatusID('Complete')), 
		('2018-10-28 13:00:00', dbo.fnGetTeamID('Buccaneers'), dbo.fnGetTeamID('Bengals'), 13, 14, 34, 37, dbo.fnGetStatusID('Complete')), 
		('2018-11-04 13:00:00', dbo.fnGetTeamID('Buccaneers'), dbo.fnGetTeamID('Panthers'), 15, 16, 28, 42, dbo.fnGetStatusID('Complete')), 
		('2018-11-11 13:00:00', dbo.fnGetTeamID('Redskins'), dbo.fnGetTeamID('Buccaneers'), 17, 18, 16, 3, dbo.fnGetStatusID('Complete')), 
		('2018-11-18 13:00:00', dbo.fnGetTeamID('Buccaneers'), dbo.fnGetTeamID('Giants'), 19, 20, 35, 38, dbo.fnGetStatusID('Complete')), 
		('2018-11-25 13:00:00', dbo.fnGetTeamID('Buccaneers'), dbo.fnGetTeamID('49ers'), 21, 22, 9, 27, dbo.fnGetStatusID('Complete')), 
		('2018-12-02 13:00:00', dbo.fnGetTeamID('Buccaneers'), dbo.fnGetTeamID('Panthers'), 23, 24, 17, 24, dbo.fnGetStatusID('Complete')), 
		('2018-12-09 13:00:00', dbo.fnGetTeamID('Buccaneers'), dbo.fnGetTeamID('Saints'), 25, 26, null, null, dbo.fnGetStatusID('Scheduled'))

END

-- End tables --


-- Views --


IF OBJECT_ID('vGames') IS NOT NULL
DROP VIEW vGames;

GO
-- vGames powers the "All Games" report for Sports Betting Analyzers to view all games to find new trends.
CREATE VIEW vGames 
AS 
	SELECT	GameID, 
			CONVERT(varchar, StartDate, 101) AS StartDate, 
			AwayTeam.Name AS 'AwayTeam',
			HomeTeam.Name AS 'HomeTeam',
			Status.Name AS Status, 
			Game.AwayTeamScore,
			Game.HomeTeamScore,
			AwayTeamLine.MoneyLineOdds AS 'AwayTeamMoneyLineOdds',
			HomeTeamLine.MoneyLineOdds AS 'HomeTeamMoneyLineOdds',
			CONVERT(DOUBLE PRECISION, AwayTeamLine.PointSpread) AS 'AwayTeamPointSpread', -- removes trailing zeros 
			CONVERT(DOUBLE PRECISION, HomeTeamLine.PointSpread) AS 'HomeTeamPointSpread',
			AwayTeamLine.SpreadOdds AS 'AwayTeamSpreadOdds', 
			HomeTeamLine.SpreadOdds AS 'HomeTeamSpreadOdds'
	FROM Game
	JOIN Team AS AwayTeam ON Game.AwayTeamID = AwayTeam.TeamID
	JOIN Team AS HomeTeam ON Game.HomeTeamID = HomeTeam.TeamID
	JOIN Line AS AwayTeamLine ON Game.AwayTeamLineID = AwayTeamLine.LineID
	JOIN Line AS HomeTeamLine ON Game.HomeTeamLineID = HomeTeamLine.LineID
	JOIN Status ON Game.StatusID = Status.StatusID
GO

-- View: vQuestion1
-- Question #1: Are there any teams that predictably fail to cover the point spread when 
-- they are a heavy favorite and their last game involved playing a team in the same division?
IF OBJECT_ID('vQuestion1') IS NOT NULL
DROP VIEW vQuestion1;
GO
CREATE VIEW vQuestion1
AS
	SELECT Cast(Cast((
		CAST((SELECT	COUNT(GameID)
		FROM Game 
		JOIN Team AS AwayTeam ON Game.AwayTeamID = AwayTeam.TeamID
		JOIN Team AS HomeTeam ON Game.HomeTeamID = HomeTeam.TeamID
		JOIN Line AS AwayTeamLine ON Game.AwayTeamLineID = AwayTeamLine.LineID
		JOIN Line AS HomeTeamLine ON Game.HomeTeamLineID = HomeTeamLine.LineID
		JOIN Status ON Game.StatusID = Status.StatusID
		JOIN Division AS AwayTeamDivision ON AwayTeam.DivisionID = AwayTeamDivision.DivisionID
		JOIN Division AS HomeTeamDivision ON HomeTeam.DivisionID = HomeTeamDivision.DivisionID
		WHERE
			(AwayTeamID = dbo.fnGetTeamID('Buccaneers') OR HomeTeamID = dbo.fnGetTeamID('Buccaneers')) AND 
			Status.Name = 'Complete' AND 
			AwayTeamDivision.Name = HomeTeamDivision.Name AND 
			dbo.fnDidTeamCoverNextGame(dbo.fnGetTeamID('Buccaneers'), Game.StartDate, 6.5) = 0 -- Value of 1 would mean they covered, we are detecting non-covers.
		) AS FLOAT) / 
		CAST((SELECT	COUNT(GameID)
		FROM Game 
		JOIN Team AS AwayTeam ON Game.AwayTeamID = AwayTeam.TeamID
		JOIN Team AS HomeTeam ON Game.HomeTeamID = HomeTeam.TeamID
		JOIN Line AS AwayTeamLine ON Game.AwayTeamLineID = AwayTeamLine.LineID
		JOIN Line AS HomeTeamLine ON Game.HomeTeamLineID = HomeTeamLine.LineID
		JOIN Status ON Game.StatusID = Status.StatusID
		JOIN Division AS AwayTeamDivision ON AwayTeam.DivisionID = AwayTeamDivision.DivisionID
		JOIN Division AS HomeTeamDivision ON HomeTeam.DivisionID = HomeTeamDivision.DivisionID
		WHERE
			(AwayTeamID = dbo.fnGetTeamID('Buccaneers') OR HomeTeamID = dbo.fnGetTeamID('Buccaneers')) AND 
			Status.Name = 'Complete' AND 
			AwayTeamDivision.Name = HomeTeamDivision.Name
		) AS FLOAT)
	)*100 AS int) AS varchar(5)) + ' %' AS 'Percentage Covered'
GO


-- View: vQuestion2
-- Question #2: Are there any upcoming games for a given trend?
-- Using Question #3 as given trend.
IF OBJECT_ID('vQuestion2') IS NOT NULL
DROP VIEW vQuestion2;
GO
CREATE VIEW vQuestion2
AS
	SELECT * 
	FROM vGames 
	WHERE 
		Status = 'Scheduled' AND 
		dbo.fnDidTeamLoseLast2AwayGames(dbo.fnGetTeamID(AwayTeam), vGames.StartDate) = 1
GO


-- View vQuestion3
-- Question 3: Are there any teams that predictably fail to cover the point spread on their third game of a 
-- three or more-game road trip, when they have lost the last two games?
IF OBJECT_ID('vQuestion3') IS NOT NULL
DROP VIEW vQuestion3;
GO
CREATE VIEW vQuestion3
AS
	SELECT Cast(Cast((
		CAST((SELECT	COUNT(GameID)
		FROM Game 
		JOIN Line AS AwayTeamLine ON Game.AwayTeamLineID = AwayTeamLine.LineID
		WHERE AwayTeamID = dbo.fnGetTeamID('Buccaneers') 
			AND (Game.HomeTeamScore - Game.AwayTeamScore) > AwayTeamLine.PointSpread
			AND dbo.fnDidTeamLoseLast2AwayGames(dbo.fnGetTeamID('Buccaneers'), Game.StartDate) = 1)
	AS FLOAT) / CAST((SELECT	COUNT(GameID)
		FROM Game 
		WHERE AwayTeamID = dbo.fnGetTeamID('Buccaneers') 
		AND dbo.fnDidTeamLoseLast2AwayGames(dbo.fnGetTeamID('Buccaneers'), Game.StartDate) = 1) 
	AS FLOAT)

	)*100 AS int) AS varchar(5)) + ' %' AS 'Percentage Not Covered'
GO	

	

-- View: vQuestion4
-- Question #4: In football, do teams predictably cover the spread when the point spread on the team is exactly +2.5

IF OBJECT_ID('vQuestion4') IS NOT NULL
DROP VIEW vQuestion4;
GO
CREATE VIEW vQuestion4
AS
	SELECT Cast(Cast((
		CAST((SELECT	COUNT(GameID)
		FROM vGames 
		WHERE (AwayTeamPointSpread = 2.5 AND (HomeTeamScore - AwayTeamScore) < 2.5) OR 
			HomeTeamPointSpread = 2.5 AND (AwayTeamScore - HomeTeamScore) < 2.5
		) AS FLOAT)
		 / 
		CAST((SELECT	COUNT(GameID)
		FROM vGames 
		WHERE AwayTeamPointSpread = 2.5 OR HomeTeamPointSpread = 2.5) AS FLOAT)
	)*100 AS int) AS varchar(5)) + ' %' AS 'Percentage Covered'
GO

-- View: vQuestion5
-- Question #5: In testing a trend, theoretically, how much money would a bettor have 
-- won or lost if they bet a given trend in the past?
-- Will calculate money lost/won on trend from Question #4
IF OBJECT_ID('vQuestion5') IS NOT NULL
DROP VIEW vQuestion5;
GO
CREATE VIEW vQuestion5
AS
	SELECT (
		-- Winners
		(SELECT	COALESCE(SUM(

			-- Calculates $$ made from each Spread odd. 
			CASE
				WHEN(AwayTeamSpreadOdds < 0)
					THEN (100/AwayTeamSpreadOdds) * 100
				ELSE AwayTeamSpreadOdds
			END

		),0)
		FROM vGames 
		WHERE (AwayTeamPointSpread = 2.5 AND (HomeTeamScore - AwayTeamScore) < 2.5) 
		) + 
		(SELECT	COALESCE(SUM(
		
			-- Calculates $$ made from each Spread odd. 
			CASE
				WHEN(HomeTeamSpreadOdds < 0)
					THEN (100/HomeTeamSpreadOdds) * 100
				ELSE HomeTeamSpreadOdds
			END		
		), 0)
		FROM vGames 
		WHERE (HomeTeamPointSpread = 2.5 AND (AwayTeamScore - HomeTeamScore) < 2.5) 
		) -
		-- Losers
		(SELECT	COUNT(GameID) * 100 -- $100 was lost each row found
		FROM vGames 
		WHERE (AwayTeamPointSpread = 2.5 AND (HomeTeamScore - AwayTeamScore) > 2.5) 
		) - 
		(SELECT COUNT(GameID) * 100 -- $100 was lost each row found
		FROM vGames 
		WHERE (HomeTeamPointSpread = 2.5 AND (AwayTeamScore - HomeTeamScore) > 2.5) 
		) 

	) AS 'Profit betting $100 per game'
GO

-- End Views --

-- Stored Procedures --
-- spInsertGame, used by the game input role, inserts a game into the game table.
GO
IF OBJECT_ID('spInsertGame') IS NOT NULL
DROP PROCEDURE spInsertGame;
GO
CREATE PROCEDURE spInsertGame 
	@StartDate DateTime, 
	@AwayTeam varchar(50), 
	@HomeTeam varchar(50), 
	@AwayTeamScore int,
	@HomeTeamScore int,
	@AwayTeamMoneyLine int,
	@AwayTeamPointSpread decimal(3,1),
	@AwayTeamSpreadOdds int,
	@HomeTeamMoneyLine int,
	@HomeTeamPointSpread decimal(3,1),
	@HomeTeamSpreadOdds int,
	@Status varchar(50)
AS
BEGIN
	-- Detect if away team line can be entered, and store the line id if entered
	DECLARE @AwayTeamLineID int;
	IF(@AwayTeamMoneyLine IS NOT NULL AND
		@AwayTeamPointSpread IS NOT NULL AND 
		@AwayTeamSpreadOdds IS NOT NULL)
	BEGIN
		INSERT INTO Line(MoneyLineOdds, PointSpread, SpreadOdds)
		VALUES(@AwayTeamMoneyLine, @AwayTeamPointSpread, @AwayTeamSpreadOdds)
		SET @AwayTeamLineID = @@IDENTITY
	END

	-- Detect if home line can be entered, and store the line id if entered
	DECLARE @HomeTeamLineID int;
	IF(@HomeTeamMoneyLine IS NOT NULL AND 
		@HomeTeamPointSpread IS NOT NULL AND 
		@HomeTeamSpreadOdds IS NOT NULL)
	BEGIN
		INSERT INTO Line(MoneyLineOdds, PointSpread, SpreadOdds)
		VALUES(@HomeTeamMoneyLine, @HomeTeamPointSpread, @HomeTeamSpreadOdds)
		SET @HomeTeamLineID = @@IDENTITY
	END

	-- Finally, insert a game
	INSERT INTO Game(
		StartDate, 
		AwayTeamID, 
		HomeTeamID, 
		AwayTeamLineID, 
		HomeTeamLineID, 
		AwayTeamScore, 
		HomeTeamScore, 
		StatusID
	)
	VALUES(
		@StartDate, 
		dbo.fnGetTeamID(@AwayTeam), 
		dbo.fnGetTeamID(@HomeTeam), 
		@AwayTeamLineID, 
		@HomeTeamLineID, 
		@AwayTeamScore, 
		@HomeTeamScore, 
		dbo.fnGetStatusID(@Status)
	)
	SELECT @@IDENTITY
END
-- Example: EXEC spInsertGame '2018-12-12 13:00:00', 'Giants', 'Patriots', 48, 49, 100, 2.5, 100, 100, -2.5, 100, 'Scheduled'
GO
IF OBJECT_ID('spUpdateGame') IS NOT NULL
DROP PROCEDURE spUpdateGame;
GO
CREATE PROCEDURE spUpdateGame 
	@GameID int,
	@StartDate DateTime, 
	@AwayTeam varchar(50), 
	@HomeTeam varchar(50), 
	@AwayTeamScore int,
	@HomeTeamScore int,
	@AwayTeamMoneyLine int,
	@AwayTeamPointSpread decimal(3,1),
	@AwayTeamSpreadOdds int,
	@HomeTeamMoneyLine int,
	@HomeTeamPointSpread decimal(3,1),
	@HomeTeamSpreadOdds int,
	@Status varchar(50)
AS
BEGIN
	-- Detect if away team line exists, if so modify, otherwise create new line
	DECLARE @AwayTeamLineID int = (SELECT AwayTeamLineID from Game WHERE GameID = @GameID);
	IF(@AwayTeamLineID IS NULL)
		BEGIN
			IF(	@AwayTeamMoneyLine IS NOT NULL AND
				@AwayTeamPointSpread IS NOT NULL AND 
				@AwayTeamSpreadOdds IS NOT NULL)
			BEGIN
				INSERT INTO Line(MoneyLineOdds, PointSpread, SpreadOdds)
				VALUES(@AwayTeamMoneyLine, @AwayTeamPointSpread, @AwayTeamSpreadOdds)
				SET @AwayTeamLineID = @@IDENTITY
			END
		END
	ELSE
		UPDATE Line SET 
			MoneyLineOdds = @AwayTeamMoneyLine, 
			PointSpread	= @AwayTeamPointSpread, 
			SpreadOdds = @AwayTeamSpreadOdds
		WHERE LineID = @AwayTeamLineID

	
	-- Detect if home team line exists, if so modify, otherwise create new line
	DECLARE @HomeTeamLineID int = (SELECT HomeTeamLineID from Game WHERE GameID = @GameID);
	IF(@HomeTeamLineID IS NULL)
		BEGIN
			IF(	@HomeTeamMoneyLine IS NOT NULL AND
				@HomeTeamPointSpread IS NOT NULL AND 
				@HomeTeamSpreadOdds IS NOT NULL)
			BEGIN
				INSERT INTO Line(MoneyLineOdds, PointSpread, SpreadOdds)
				VALUES(@HomeTeamMoneyLine, @HomeTeamPointSpread, @HomeTeamSpreadOdds)
				SET @HomeTeamLineID = @@IDENTITY
			END
		END
	ELSE
		BEGIN
			UPDATE Line SET 
				MoneyLineOdds = @HomeTeamMoneyLine, 
				PointSpread	= @HomeTeamPointSpread, 
				SpreadOdds = @HomeTeamSpreadOdds
			WHERE LineID = @HomeTeamLineID
		END

	-- Finally, update the game
	UPDATE Game SET 
		StartDate = @StartDate, 
		AwayTeamID = dbo.fnGetTeamID(@AwayTeam), 
		HomeTeamID = dbo.fnGetTeamID(@HomeTeam), 
		AwayTeamLineID = @AwayTeamLineID, 
		HomeTeamLineID = @HomeTeamLineID, 
		AwayTeamScore = @AwayTeamScore, 
		HomeTeamScore = @HomeTeamScore, 
		StatusID = dbo.fnGetStatusID(@Status)
	WHERE GameID = @GameID;
	SELECT @@IDENTITY
END
-- Example: EXEC spUpdateGame 1, '2018-12-12 13:00:00', 'Giants', 'Patriots', 48, 49, 100, 3.5, 100, 100, -3.5, 100, 'Cancelled'

GO
IF OBJECT_ID('spDeleteGame') IS NOT NULL
DROP PROCEDURE spDeleteGame;
GO
CREATE PROCEDURE spDeleteGame 
	@GameID int
AS
BEGIN
	-- Detect if line items exist, if so delete
	DECLARE @AwayTeamLineID int = (SELECT AwayTeamLineID FROM Game WHERE GameID = @GameID);
	DECLARE @HomeTeamLineID int = (SELECT AwayTeamLineID FROM Game WHERE GameID = @GameID);

	IF(@AwayTeamLineID IS NOT NULL)
		DELETE FROM Line WHERE LineID = @AwayTeamLineID

	IF(@HomeTeamLineID IS NOT NULL)
		DELETE FROM Line WHERE LineID = @HomeTeamLineID

	DELETE FROM Game WHERE GameID = @GameID
END

-- End Stored Procedures --

-- END INSTALL --
