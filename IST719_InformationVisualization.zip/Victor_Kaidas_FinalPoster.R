# 
# Author: Victor Kaidas
# Purpose: Project
# Kaggle: https://www.kaggle.com/c/nfl-big-data-bowl-2020

library(ggplot2)
library(RColorBrewer)
library(viridisLite)
library(dplyr)

data <- read.csv('/Users/victo/Documents/Syr/Viz/Proj/nfl-big-data-bowl-2020.csv'
                 , stringsAsFactors=F, header=T)

data <- data[data$NflIdRusher==data$NflId,]

rand <- sample(1:nrow(data), round(nrow(data)*.05), replace=F)
some <- data[rand,]

#par(mfrow=c(2,2))

# 1
pie(table(data$Down)
    , main="Running Plays by Down")

# 2
barplot(table(data$Quarter)
        , main="Running Plays by Quarter"
        , xlab="Quarter"
        , ylab="Frequency")

# 3
boxplot(data$Yards 
        , main="Running Plays by Yards Gained")

# 4


date_diff <- as.Date(as.character("10/26/2019"), format="%m/%d/%Y")-
  as.Date(as.character(data$PlayerBirthDate), format="%m/%d/%Y")
age <- date_diff/365

# height in color does not seem to show a story
# 
# height <- strsplit(some$PlayerHeight, '-')
# height <- ((height[,1]) * 12) + height[,2]
# 
# height_inches <- c()
# for(i in c(1:length(height))) {
#   x <- 0
#   x <- (as.numeric(height[[i]][1]) * 12)
#   x <- x + as.numeric(height[[i]][2])
#   height_inches <- c(height_inches, x)
# }
# 
# 
# breaks <- c(66,68,70,72,74,76,78,80,82)
# # specify interval/bin labels
# tags <- c(1:8)
# # bucketing values into bins
# group_tags <- cut(height_inches, 
#                   breaks=breaks, 
#                   include.lowest=TRUE, 
#                   right=FALSE, 
#                   labels=tags)
# 
# FUN <- colorRampPalette(c("blue", "red"))
# my.cols <- FUN(8)

plot(data$Yards, age
     , main = "Rushing Yards by Player Age"
     , xlab = "Yards"
     , ylab = "Age"
     , col = rgb(.8, .15, .15, alpha=.3)
     , pch=16)

# by Formation
agg_oForm <- aggregate(data$Yards, list(data$OffenseFormation), mean)
names(agg_oForm) <- c('Formation', 'Yards')
agg_oForm <- agg_oForm[agg_oForm$Formation!='EMPTY',]
agg_oForm <- agg_oForm[agg_oForm$Formation!='',]

# Minimal theme + blue fill color
ggplot(data=agg_oForm, aes(x=Formation, y=Yards)) +
  geom_bar(stat="identity", fill="steelblue")+
  coord_flip() + 
  labs(title="Avg Rushing Yards per Formation")


## Putting theta on 'Y' gives a weird sort of bullseye plot.  Uses a width of
## .9 to produce space between bars.
#install.packages("viridis")
library("viridis")  
ggplot(agg_oForm, aes(x = Formation, y=Yards, fill=c(1:7))) + 
  geom_bar(width = 0.85, stat='identity') + 
  coord_polar(theta = "y") +
  xlab('') + ylab('') + title('Yards per O-Formation') + 
  theme_minimal() + 
  theme(legend.position='none', axis.text.y=element_blank(), axis.ticks=element_blank()) + 
  ylim(c(0,5)) + 
  #scale_color_brewer(palette = "Dark1") + 
  geom_text(data=agg_oForm, hjust=1, size=3, aes(x=Formation, y=0, label=Formation)) 
  
   

# clock

for(i in 1:nrow(data)) {
  
  t <- data$GameClock[i]
  tt <- strptime(t,"%M:%S")
  m <- as.numeric(format(tt, '%M'))
  s <- as.numeric(format(tt, '%S'))
  data$Minute[i] <- m * data$Quarter[i]
}

agg_minute <- aggregate(data$Yards, list(data$Minute), mean)
names(agg_minute) <- c('Time', 'Yards')

# Minimal theme + blue fill color
ggplot(data=agg_minute, aes(x=Time, y=Yards)) +
  geom_bar(stat="identity", fill="steelblue")+
  theme_minimal() + 
  coord_flip()

# density of time
ggplot(data, aes(x=Minute))+
  geom_density(color="darkblue", fill="lightblue") + 
  labs(title="Frequency of Rushes by Game Time",
       x ="Time", y = "Density")



#      PISTOL 4.556309



# todo: color by addl factors:
# StadiumType - description of the stadium environment 
# Turf - description of the field surface
# GameWeather - description of the game weather
# Temperature - temperature (deg F)
# Humidity - humidity
# WindSpeed - wind speed in miles/hour
# WindDirection - wind direction

# Weather
rain <- c(
  'Rainy', 'Rain Chance 40%', 'Showers',
  'Cloudy with periods of rain, thunder possible. Winds shifting to WNW, 10-20 mph.',
  'Scattered Showers', 'Cloudy, Rain', 'Rain shower', 'Light Rain', 'Rain'
)
overcast <- c(
  'Cloudy, light snow accumulating 1-3"', 'Party Cloudy', 'Cloudy, chance of rain',
  'Coudy', 'Cloudy, 50% change of rain', 'Rain likely, temps in low 40s.',
  'Cloudy and cold', 'Cloudy, fog started developing in 2nd quarter',
  'Partly Clouidy', '30% Chance of Rain', 'Mostly Coudy', 'Cloudy and Cool',
  'cloudy', 'Partly cloudy', 'Overcast', 'Hazy', 'Mostly cloudy', 'Mostly Cloudy',
  'Partly Cloudy', 'Cloudy'
)
clear <- c(
  'Partly clear', 'Sunny and clear', 'Sun & clouds', 'Clear and Sunny',
  'Sunny and cold', 'Sunny Skies', 'Clear and Cool', 'Clear and sunny',
  'Sunny, highs to upper 80s', 'Mostly Sunny Skies', 'Cold',
  'Clear and warm', 'Sunny and warm', 'Clear and cold', 'Mostly sunny',
  'T: 51; H: 55; W: NW 10 mph', 'Clear Skies', 'Clear skies', 'Partly sunny',
  'Fair', 'Partly Sunny', 'Mostly Sunny', 'Clear', 'Sunny'
)
snow  <- c('Heavy lake effect snow', 'Snow')
none  <- c('N/A Indoor', 'Indoors', 'Indoor', 'N/A (Indoors)', 'Controlled Climate')

group_game_weather <- function(weather) {
  
  if(weather %in% rain) {
    return('rain')
  }
  else if (weather %in% overcast) {
    return ('overcast')
  }
  else if (weather %in% clear) {
    return ('clear')
  }  
  else if (weather %in% snow) {
    return ('snow')
  }
  else {
    return('none')
  }
}

for(d in 1:nrow(data)) {
  data$GameWeather_vk[d] <- group_game_weather(data$GameWeather[d])
}

table(data$GameWeather_vk)
agg_weather <- aggregate(data$Yards, list(data$GameWeather_vk), mean)
names(agg_weather) <- c('Weather', 'Yards')

#ggplot(data=agg_weather, aes(x=Weather, y=Yards)) +
#  geom_bar(stat="identity", fill="steelblue")+
#  coord_flip() + 
#  labs(title="Rushing Yards by Weather")

data$GameWeather_vk[data$GameWeather_vk=='none'] <- 'indoor'
df <- as.data.frame(table(data$GameWeather_vk))
ggplot(data=df, aes(x=Var1, y=Freq)) +
    geom_bar(stat="identity", fill="steelblue")+
    coord_flip() + 
    labs(title="Rushing Attempts by Weather", x='Weather', y='Frequency')

boxplot(data$Yards~data$GameWeather_vk)

ggplot(data, aes(y=Yards, x=Quarter)) + 
  geom_boxplot()



barplot(agg$x, agg$Group.1)
barplot(t(as.matrix((data.frame(agg,row.names=1)))))

#1    clear 4.274997
#2     none 4.063009
#3 overcast 4.314997
#4     rain 4.324648
#5     snow 4.263682








# StadiumTypes
outdoor <- c(
  'Outdoor', 'Outdoors', 'Cloudy', 'Heinz Field', 
  'Outdor', 'Ourdoor', 'Outside', 'Outddors', 
  'Outdoor Retr Roof-Open', 'Oudoor', 'Bowl'
)
indoor_closed <- c(
  'Indoors', 'Indoor', 'Indoor, Roof Closed', 'Indoor, Roof Closed', 
  'Retractable Roof', 'Retr. Roof-Closed', 'Retr. Roof - Closed', 'Retr. Roof Closed'
)
indoor_open <- c('Indoor, Open Roof', 'Open', 'Retr. Roof-Open', 'Retr. Roof - Open')
dome_closed <- c('Dome', 'Domed, closed', 'Closed Dome', 'Domed', 'Dome, closed')
dome_open <- c('Domed, Open', 'Domed, open')

group_stadium_types <- function(stadium) {
  
  if(stadium %in% outdoor) {
    return ('outdoor')
  }
  else if(stadium %in% indoor_closed) {
    return ('indoor_closed')
  }
  else if(stadium %in% indoor_open) {
    return ('indoor_open')
  }
  else if(stadium %in% dome_closed) {
    return ('dome_closed')
  }  
  else if(stadium %in% dome_open) {
    return ('dome_open')
  }  
  else {
    return('unknown')
  }
}

for(d in c(1:nrow(data))) {
  some$StadiumType_vk[d] <- group_stadium_types(some$StadiumType[d])
}

aggregate(some$Yards, list(some$StadiumType_vk), mean)
#1   dome_closed 3.971937
#2     dome_open 3.850649
#3 indoor_closed 4.008504
#4   indoor_open 3.685430
#5       outdoor 4.347401
#6       unknown 4.497841

agg <- aggregate(some$Yards, list(some$StadiumType_vk), mean)
barplot(t(as.matrix((data.frame(agg,row.names=1)))))






# turf
turf <- c('Artifical', 'Artificial', 'DD GrassMaster', 'Field turf'
          , 'Field Turf', 'FieldTurf'
          , 'Twenty-Four/Seven Turf'
)
grass <- c('grass', 'Grass', 'Natural', 'natural grass', 'Natural grass', 'Natural Grass'
           , 'Naturall Grass'
)
turf_360 <- c('FieldTurf 360', 'FieldTurf360')
ubu <- c('UBU Speed Series-S5-M', 'UBU Sports Speed S5-M')

get_turf_type <- function(turf_type) {
  
  if(turf_type %in% turf) {
    return ('turf')
  }
  else if (turf_type %in% grass) {
    return ('grass')
  }
  else if (turf_type %in% turf_360) {
    return ('FieldTurf360')
  }  
  else if (turf_type %in% ubu) {
    return ('UBU')
  }    
  else return(turf_type)
}

for(d in c(1:nrow(data))) {
  data$Turf_vk2[d] <- get_turf_type(data$Turf[d])
}


agg <- aggregate(data$Yards, list(data$Turf_vk2), mean)
barplot(t(as.matrix((data.frame(agg,row.names=1))))
        , ylim=c(0,5))
# full data: 
#1   grass 4.194295
#2    turf 4.234720

# maybe diff kinds of turf are better? (vk2)
data$Turf_vk2[data$Turf=='UBU Sports Speed S5-M'] <- 'UBU Speed Series-S5-M'
# SISGrass .5 above others






# Physical attr's

# age
date_diff <- as.Date(as.character("02/06/2019"), format="%m/%d/%Y")-
  as.Date(as.character(data$PlayerBirthDate), format="%m/%d/%Y")
data$Age_vk <- round(as.numeric(date_diff/365), 0)

agg_yards <- aggregate(data$Yards, list(data$Age_vk), mean)
agg_yards <- agg_yards[order(agg_yards$Group.1),]
agg_yards$Type <- 'Distance (Yards)'
names(agg_yards) <- c('Age', 'Metric', 'Type')

agg_speed <- aggregate(data$S, list(data$Age_vk), mean)
agg_speed <- agg_speed[order(agg_speed$Group.1),]
agg_speed$Type <- 'Speed'
names(agg_speed) <- c('Age', 'Metric', 'Type')

agg_acc <- aggregate(data$A, list(data$Age_vk), mean)
agg_acc <- agg_acc[order(agg_acc$Group.1),]
agg_acc$Type <- 'Acceleration'
names(agg_acc) <- c('Age', 'Metric', 'Type')

agg_all_performance <- rbind(agg_yards, agg_speed, agg_acc)

ggplot(agg_all_performance, aes(x = Age, y = Metric, color = Type)) + 
  geom_smooth(method = lm, formula = y ~ splines::bs(x, 3), se = FALSE)

# height
height <- strsplit(data$PlayerHeight, '-')
height_inches <- c()
for(i in c(1:length(height))) {
   x <- 0
   x <- (as.numeric(height[[i]][1]) * 12)
   x <- x + as.numeric(height[[i]][2])
   height_inches <- c(height_inches, x)
}

agg_yards <- aggregate(data$Yards, list(height_inches), mean)
agg_yards <- agg_yards[order(agg_yards$Group.1),]
agg_yards$Type <- 'Distance (Yards)'
names(agg_yards) <- c('Height', 'Metric', 'Type')

agg_speed <- aggregate(data$S, list(height_inches), mean)
agg_speed <- agg_speed[order(agg_speed$Group.1),]
agg_speed$Type <- 'Speed'
names(agg_speed) <- c('Height', 'Metric', 'Type')

agg_acc <- aggregate(data$A, list(height_inches), mean)
agg_acc <- agg_acc[order(agg_acc$Group.1),]
agg_acc$Type <- 'Acceleration'
names(agg_acc) <- c('Height', 'Metric', 'Type')

agg_all_performance <- rbind(agg_yards, agg_speed, agg_acc)

ggplot(agg_all_performance, aes(x = Height, y = Metric, color = Type)) + 
  geom_smooth(method = lm, formula = y ~ splines::bs(x, 3), se = FALSE) +
  theme_gray()

# weight
agg_yards <- aggregate(data$Yards, list(data$PlayerWeight), mean)
agg_yards <- agg_yards[order(agg_yards$Group.1),]
agg_yards$Type <- 'Distance (Yards)'
names(agg_yards) <- c('Weight', 'Metric', 'Type')

agg_speed <- aggregate(data$S, list(data$PlayerWeight), mean)
agg_speed <- agg_speed[order(agg_speed$Group.1),]
agg_speed$Type <- 'Speed'
names(agg_speed) <- c('Weight', 'Metric', 'Type')

agg_acc <- aggregate(data$A, list(data$PlayerWeight), mean)
agg_acc <- agg_acc[order(agg_acc$Group.1),]
agg_acc$Type <- 'Acceleration'
names(agg_acc) <- c('Weight', 'Metric', 'Type')

agg_all_performance <- rbind(agg_yards, agg_speed, agg_acc)

ggplot(agg_all_performance, aes(x = Weight, y = Metric, color = Type)) + 
  geom_smooth(method = lm, formula = y ~ splines::bs(x, 3), se = FALSE) 







### Team sonars

data <- data %>% 
  mutate(ToLeft = PlayDirection == "left", 
         IsBallCarrier = NflId == NflIdRusher)

data <- data %>% 
  mutate(Dir_std_1 = ifelse(ToLeft & Dir < 90, Dir + 360, Dir), 
         Dir_std_1 = ifelse(!ToLeft & Dir > 270, Dir - 360, Dir_std_1), 
         Dir_std_2 = ifelse(ToLeft, Dir_std_1 - 180, Dir_std_1))

data <- data %>% 
  mutate(IsSuccess = ifelse(Down == 1, Yards >= Distance/2, 
                            ifelse(Down == 2, Yards >= Distance/2, Yards >= Distance)))

round_angle <- 15
data <- data %>% 
  mutate(AngleRound = round(Dir_std_2/round_angle)*round_angle)



sonar <- data %>%
  mutate(N=n()) %>%
  group_by(AngleRound, PossessionTeam)  %>%
  mutate(n_rushes = n(), n_angle=n_rushes/N) %>%
  filter(n_rushes >= 5) %>% 
  ungroup() %>%
  group_by(PossessionTeam) %>% 
  mutate(maxN = max(n_angle),
         AngleNorm = n_angle/maxN) %>%
  ungroup() %>%
  group_by(AngleRound, PossessionTeam, N)%>%
  summarize(AngleNorm = mean(AngleNorm),
            SuccessRate = mean(IsSuccess)) %>% 
  arrange(PossessionTeam)


summary(sonar$AngleRound)



options(repr.plot.width=12, repr.plot.height=8)
p_rb <- ggplot(sonar) +
  geom_bar(aes(x=AngleRound, y = AngleNorm, fill= SuccessRate), stat="identity") +
  scale_x_continuous(breaks=seq(0, 360, by=90), limits=c(0, 360)) +
  coord_polar(start=4.58, direction=1) + ### rotate (270-15/2) degrees, or 4.58 radians
  scale_fill_viridis("Success Rate", na.value="#FDE725FF", 
                     limits = c(0.3, 0.7), 
                     breaks = c(0.3, 0.4, 0.5, 0.6, 0.7), 
                     labels = scales::percent) +
  labs(x='', y='') +
  theme_void(15)+
  theme(plot.title = element_text(hjust=0.5),
        legend.title = element_text(hjust = 1),
        #legend.position = "top", #uncomment to remove colorbar
        plot.background = element_rect(fill = "transparent",colour = NA),
        panel.background = element_rect(fill = "transparent",colour = NA), 
        panel.spacing = unit(0, "lines"), 
        plot.margin = margin(0, 0, 0, 0, "cm")) + 
  facet_wrap(~PossessionTeam, nrow = 4) + 
  labs(title = "Team sonars, 2017-2018", subtitle = "  ")
p_rb






